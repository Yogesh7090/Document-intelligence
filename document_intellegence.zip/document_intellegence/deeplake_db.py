from deeplake.core.vectorstore import VectorStore
import logging

"""DeeplakeDB class is defined to create the DEEPLAKE DB to store all the embeddings with their
    Metadata in order to search and retrieve the answers."""

class DeeplakeDB:
    logger                 = logging.getLogger(__name__)
    EMPTY_LIST = []
    EMPTY_STR = ''

    def create_deeplake_database(self,resume_text,vectors,dataset_path,doc_file_path_list):
        """This function will take resume_text("chronic cough is the...."), vectors(array[0.89979,1.74845],
            dataset_path('R:\Sandhiya\Office_Projects\DOC_Retrievel\Document retrieval\Doc_Retrieval_DeeplakeDB_Ver1\deeplake_dataset')
            to create an vector store and returns it.)
            
            returns vector store -> creates an vector db in local(dataset path)"""
        try:
            vector_store = VectorStore(
            path = dataset_path,overwrite=True
                )

            vector_store.add(text = resume_text, 
                            embedding= vectors, 
                            metadata = doc_file_path_list,
            )
            return vector_store
        
        except Exception as e:
            self.logger.critical(f'Error due to {e}', exc_info=True)
            return self.EMPTY_LIST

    def vector_search(self,vector_store,query_embeddings):
        """This takes the vector store(DB), query_embeddings(array[0.454567,4.925677] and do the search
            and returns the result as dictionary.)
            
            returns data -> result {'score': [0.8323328495025635], 'text': ['Cough Definition Cough is a sudden expulsion of air from the lungs through the mouth, typically \naccompanied by a distinctive sound. Coughing may happen intentionally or as a reaction to \nairway irritation, encompassing both reflexive and non -reflexive (beha vioral) actions. During \nillness, coughing may intensify, become unproductive, and overly sensitive, triggered by stimuli \nthat typically would not provoke coughing.1 While coughing involves coordinated respiratory \nmuscle activity, its control mechanisms rel y on intricate neurophysiological processes. In \nrecent years, extensive research has focused on the neural pathways governing coughing, \nleading to a better understanding of the generation of both voluntary and induced cough.
            2 The \nHistory of Cough The histo ry of chronic cough as a medical concern dates back centuries. \nCough has been documented as a symptom across various historical medical texts and \nwritings, often considered a manifestation of underlying illnesses rather than a distinct \ncondition in itself. 
            3 Throughout history, chronic cough was commonly associated with \ninfectious diseases like tuberculosis, pneumonia, and bronchitis. The understanding of cough \nevolved with medical advancements, especially during the 19th and 20th centuries, when the \nfocus shifted towards categorizing cough based on its duration and underlying causes.3 2 In the \nearly 20th century, the differentiation between acute and chronic cough gained prominence, \nwith chronic cough being defined as lasting for weeks or months, indicating a persistent \nunderlying condition. Medical literature started to address chronic cough as a specific concern, \ndistinct from acute episodes.4 Over time, research and clinical studies have expanded our \ncomprehension of chronic cough, leading to the recogniti on of various conditions contributing \nto its persistence, including asthma, gastroesophageal reflux disease (GERD), chronic \nobstructive pulmonary disease (COPD), and upper airway syndromes, among others.
            5 Acute \nVs. Chronic Cough Cough is categorized into a cute and chronic based on its duration. An acute \ncough, lasting less than 3 weeks, is typically short -lived and often linked to upper respiratory \ninfections. On the other hand, a cough persisting beyond 8 weeks is termed chronic cough. \nWhile supportive mea sures may suffice for the self -limited acute cough, managing chronic \ncough, lasting for months or even years, often presents a significant challenge due to clinicians’ \ninadequate understanding of the underlying physiological mechanisms and the lack of effe ctive \ntreatments to alleviate it.1,6 Epidemiology of Chronic Cough Cough prevalence spans a \nsignificant spectrum within communities, estimated between 2.3% to 18% in the adult \npopulation.5,7 In respiratory outpatient settings, chronic cough 3 prevalence va ries widely, \nranging from 10% to 38%.5,7 A comprehensive meta -analysis reported a general population \nchronic cough prevalence of 9.6%, defined as a cough lasting longer than three months, with \nregional disparities; higher rates were observed in Europe (12. 7%), Oceania (18.1%), and \nAmerica (11.0%) compared to lower rates in Asia (4.4%) and Africa (2.3%). Notably, this analysis \nfaced limitations due to varied definitions of chronic cough among studies.7 Further studies \nreported varying community cough prevale nce: 5.5% to 13.1% in Europe8,9, 7.3% to 13.6% in \nAustralasia8 , 2% to 11% in the United States8,10, and 1.6% to 14.1% in the United \nKingdom.8,11,12 Cough holds substantial prominence in specialized cough clinics, accounting \nfor 10% to 38% of clinic attend ees in the UK and US.5,13 Moreover, it serves as the primary \nreason for visits in general medical practice, representing 6% of encounters in Australia and the \nUS.14 Moreover, Cough ranks as the fifth most frequent concern encountered in medical \noffices, le ading to an annual expenditure of $600 million on both prescription and over -\nthe\x02counter medications, and prompting approximately 30 million office visits every year. 15 \nTypes of Chronic Cough Chronic cough manifests in distinct types based on its associat ion with \ntreatable conditions and their impact on resolving the cough. One type involves a cough \npersisting alongside treatable conditions like asthma, gastroesophageal reflux disease (GERD), \nand upper airway syndrome, where the cough tends to resolve upon  successful treatment of these underlying issues. Other well -described etiologies of chronic cough include ACE -\ninhibitor\x02induced, irritant -induced, and other forms of pulmonary disease. Up of 40% of cases, \ndespite a 4 negative medical workup and non -response to empiric therapies, patients continue \nto suffer from chronic cough. There are a variety of theories and terminologies employed to \nexplain the symptom of refractory chronic cough. Refractory chronic cough is sometimes \ntermed “cough hypersensitivity syndrome,” encompassing indi viduals displaying an amplified \ncough reflex seemingly triggered by innocuous or non -noxious stimuli. Additional somewhat \nsynonymous terms used to describe a refractory chronic 
            cough include “Neurogenic Cough” or \n“Neuropathic Cough”. 16 It is important to note, that regardless of the term used, cough \nhypersensitivity syndrome, neurogenic cough, neuropathic cough, and irritable larynx are \nconsidered diagnoses of exclusion which should only be entertained after the completion of an \nexhaustive negative workup.  No matter the exact pathophysiology of the chronic cough, if the \ncough continues despite treatment based on guidelines,17 it can be simply termed refractory \ncough (RC).1  '], 
            'metadata': [{}], 'id': ['ab3bdec7-6058-11ef-85a9-b48c9d61175e']}"""
        
        try:
            data =vector_store.search(embedding = query_embeddings,k=1 )
            return data
        
        except Exception as e:
            self.logger.critical(f'Error due to {e}', exc_info=True)
            return self.EMPTY_LIST
