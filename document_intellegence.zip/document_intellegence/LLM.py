# from langchain.prompts import ChatPromptTemplate
# from langchain_openai import ChatOpenAI

import datetime
import os
import openai
import logging
from osProcessor import osProcessor
import streamlit as st

os_pro= osProcessor()


"""LLM class deals with communicating with LLM models using prompt."""

class llm_model():
    logger    = logging.getLogger(__name__)
    EMPTY_STR = ''

    def get_config_path(self):
        """function is to get the parent path from the module 
        
            returns path for logs file"""
        try:
            _ , parent_dir = os_pro.get_code_dir()
            _, grandParent_dir = os_pro.get_parent_dir(parent_dir)
            _ , qual_config_file_name = os_pro.join_paths('logging.conf', grandParent_dir, 'TS_Config')

            return True, qual_config_file_name

        except Exception as e:
            self.logger.critical(f'Error due to {e}', exc_info=True)

            return False, self.EMPTY_STR

    @st.cache_data(show_spinner='Here is your answer')
    def generate_summary(_self,text_list,keywords,max_tokens_per_request = 4000):

        """ function is to pass the relevant information to openai llm to get the formatted response
        
            returns -> response ['The history of chronic cough as a medical concern dates back centuries. 
            Cough has been documented as a symptom across various historical medical texts and writings, 
            often considered a manifestation of underlying illnesses rather than a distinct condition in itself. 
            Throughout history, chronic cough was commonly associated with infectious diseases like tuberculosis, 
            pneumonia, and bronchitis. The understanding of cough evolved with medical advancements, especially during the 19th and 20th centuries, 
            when the focus shifted towards categorizing cough based on its duration and underlying causes. In the early 20th century, 
            the differentiation between acute and chronic cough gained prominence, with chronic cough being defined as lasting for weeks or months, 
            indicating a persistent underlying condition. Medical literature started to address chronic cough as a specific concern, distinct from acute episodes. Over time, 
            research and clinical studies have expanded our comprehension of chronic cough, leading to the recognition of various conditions contributing to its persistence, 
            including asthma, gastroesophageal reflux disease (GERD), chronic obstructive pulmonary disease (COPD), and upper airway syndromes, among others.']
            
        """

        try:    
            prompt = f"""Take the {keywords} map it to {text_list}and give the correct answer alone 
            from the text list.Dont give the full answer.just only give the answer which is relevant to the keyword.
            give the query in a professional way.Before giving the answer check if it is relevant to the
            {keywords} if it is not relevant just say kindly ask the relvant questions.kindly give the answer 
            alone in a professional way. """

            response = openai.chat.completions.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "system", "content": "You are a helpful assistant."},
                        {"role": "user", "content": prompt}
                    ],
                    temperature=0,
                    max_tokens=max_tokens_per_request, 
                    seed= 42       
                )
                # Extract and parse the ranked list from the GPT-3 response
            response_to_show_in_UI = response.choices[0].message.content.split("\n")

            return response_to_show_in_UI
        
        except Exception as e:
            _self.logger.critical(f'Error due to {e}', exc_info=True)
    
    def generate_summary_for_doc(self,doc_text,word_limit = 100):
        try:    
            prompt = f""" Take the {doc_text} and summarize the text according to the{word_limit} and 
            you should not exceed {word_limit} and retain the context of the text also."""

            response = openai.chat.completions.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "system", "content": "You are a helpful assistant."},
                        {"role": "user", "content": prompt}
                    ],
                    temperature=0,
                    seed= 42       
                )
                # Extract and parse the ranked list from the GPT-3 response
            response_to_show_in_UI = response.choices[0].message.content.split("\n")

            return response_to_show_in_UI
        
        except Exception as e:
            self.logger.critical(f'Error due to {e}', exc_info=True)


  

    
    