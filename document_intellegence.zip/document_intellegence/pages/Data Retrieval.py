import logging.config
from LLM import llm_model
import openai
import os
from Embeddings import Embedding

from deeplake_db import DeeplakeDB
import streamlit as st
from dotenv import load_dotenv, find_dotenv
import logging
from logo import add_logo
import streamlit as st
from pymongo import MongoClient
from deeplake.core.vectorstore import VectorStore
import base64

st.set_page_config(
    page_title="Data Retrieval",
    
)
add_logo()
st.markdown(
    """
    <style>
    .custom-title {
        color: #005F7B;
    }
    </style>
    """,
    unsafe_allow_html=True
)

logging_config = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'simpleFormatter': {
            'format': '\n---------------------------------------------------------------------------------------------------------------------\n%(asctime)s - %(name)s(%(funcName)s) - %(levelname)s\n%(message)s'
        }
    },
    'handlers': {
        'fileHandler': {
            'class': 'logging.FileHandler',
            'level': 'DEBUG',
            'formatter': 'simpleFormatter',
            'filename': r'.\TS_Logs\document_retrieval_logs.log',
            'encoding': 'utf-8'
        }

    },
    'loggers': {
        'root': {
            'level': 'DEBUG',
            'handlers': ['fileHandler']
        },
        'pdfProcessor': {
            'level': 'DEBUG',
            'handlers': ['fileHandler'],
            'qualname': 'pdfProcessor'
        },
        'preprocessor': {
            'level': 'DEBUG',
            'handlers': ['fileHandler'],
            'qualname': 'preprocessor'
        },
        'docProcessor': {
            'level': 'CRITICAL',
            'handlers': ['fileHandler'],
            'qualname': 'docProcessor'
        },
        'Embeddings': {
            'level': 'DEBUG',
            'handlers': ['fileHandler'],
            'qualname': 'Embeddings'
        },
        'osProcessor': {
            'level': 'DEBUG',
            'handlers': ['fileHandler'],
            'qualname': 'osProcessor'
        },
        'LLM': {
            'level': 'DEBUG',
            'handlers': ['fileHandler'],
            'qualname': 'LLM'
        },
        
        'deeplake_db': {
            'level': 'DEBUG',
            'handlers': ['fileHandler'],
            'qualname': 'deeplake_db'

        }
    }
}


llm_obj = llm_model()
emb_obj = Embedding()
db_obj = DeeplakeDB()

# folder_path = r".\Docs"
dataset_path = r".\deeplake_dataset"

_, config_path = llm_obj.get_config_path()

logging.config.dictConfig(logging_config)
logger = logging.getLogger(__name__)

_ = load_dotenv(find_dotenv())  # read local .env file
# openai.api_key = os.environ['OPENAI_API_KEY']

# st.set_page_config(layout="wide")

@st.cache_data(show_spinner="Loading your answer")
def create_responses(keywords):
    try:
        doc_text_list = []
        doc_file_path_list = []
        jd_embeddings = emb_obj.create_embeddings_for_keywords(keywords)
  
        COLLECTION_NAME = 'doc_files'
        client = MongoClient()
        db = client.document_data

        collection = db[COLLECTION_NAME]

        all_files = collection.find()
        for file in all_files:
            doc_text_list.append(file['pdf_files'])
            doc_file_path_list.append(file['file_path'])
      
        # print('doc text',doc_text_list)
        # print(f'{len(docs_text)}')
        db = VectorStore(
       path = dataset_path,
)
        if db:
             print('already db exist')
             results = db_obj.vector_search(db,jd_embeddings)
        else:
            response_list = emb_obj.create_embeddings_for_docs(doc_text_list)
            # print('response list',response_list)
            vectors = [emb.embedding for key, value in response_list if key == 'data' for emb in value if hasattr(emb, 'embedding')]
            db = db_obj.create_deeplake_database(doc_text_list,vectors,dataset_path,doc_file_path_list)
            results = db_obj.vector_search(db,jd_embeddings)
        # print('jd embeddings',jd_embeddings)
       
        # print('result',results)
        return results
    except Exception as e:
        logger.critical(f'Error due to {e}', exc_info=True)
       

#===========================================================================================
# streamlit app
# Initialize session state variables
if 'results' not in st.session_state.keys():
    st.session_state.results = []
if 'response' not in st.session_state.keys():
    st.session_state.response = []
if 'word_limit' not in st.session_state.keys():
    st.session_state.word_limit = 100


st.header("Query your Documents")

disabled = True

# Text input for query
keywords = st.text_input("**Enter query to get your answer.**")

# Process the query when keywords are entered
if keywords:
    disabled = False
    st.session_state.results = create_responses(keywords)

    print("final response",st.session_state.results)
    if st.session_state.results:
        st.write("**Below is your answer**:")
        text_list = st.session_state.results['text']
        score_list = st.session_state.results['score']
        file_path = st.session_state.results['metadata']
        print(f'{file_path=}')

        # Generate response (e.g., from a model or function)
        session_response = llm_obj.generate_summary(text_list, keywords)
        # st.session_state.response.append(session_response)
        # st.session_state.response = llm_obj.generate_summary(text_list, keywords)
        st.session_state.response = session_response
        # print('response',st.session_state.response)
        st.session_state.response = ', '.join(st.session_state.response)
        # for i in st.session_state.response:
    
        st.markdown(st.session_state.response)
        st.write('Accuracy_score:',str(score_list))
        # st.write(f'source of the answer:<A>{file_path[0]}</A>', unsafe_allow_html=True)
        # st.markdown(f'<a href="{file_path[0]}" target="_blank">View PDF</a>', unsafe_allow_html=True)
        st.markdown("**click on the below button to veiw the source file**")
        with open(file_path[0], "rb") as file:
            pdf_read = file.read()
            if st.download_button("Download File", file, file_name="Source_file.pdf", mime="application/octet-stream"):
                base64_pdf = base64.b64encode(pdf_read).decode('utf-8')
                pdf_display = f'<iframe src="data:application/pdf;base64,{base64_pdf}" width="700" height="1000" type="application/pdf"></iframe>'
                st.markdown(pdf_display, unsafe_allow_html=True)

        # Display the button to get the summary of the document
        st.write("**If you want to get a summary of your document, select a word limit if needed and click the button below.**")

        # Number input for word limit
        st.session_state.word_limit = st.number_input("Set summary word limit", min_value=50, max_value=300, value=100)

        # Check if the button to get the summary is clicked
    # print('disabled',disabled)
    if st.button('Click here to get the summary of your Document',disabled=disabled):
        if st.session_state.results:
            file_text =  st.session_state.results['text']
            file_text = str(file_text)
            # Ensure summarize function is properly defined
            summary = llm_obj.generate_summary_for_doc(file_text, word_limit= st.session_state.word_limit)
            # st.session_state.summary = summary  # Save summary to session state
            st.subheader("Summary")
            for i in summary:
                st.write(i)
        else:
            st.error("No document text available to summarize.")
        



