from pymongo import MongoClient
import os
import PyPDF2
from docx import Document

COLLECTION_NAME = 'doc_files'

client = MongoClient()
db = client.document_data

pdf_folder_path = r"D:\document_retrievel\Doc_Retrieval_DeeplakeDB_Ver2_EXPerimenting\Doc_Retrieval_DeeplakeDB_Ver2_EXPerimenting\Docs_1"

all_text = ""


def extract_text_from_pdf(file_path: str) -> str:
    text = ""
    with open(file_path, "rb") as f:
        reader = PyPDF2.PdfReader(f)
        for page in reader.pages:
            text += page.extract_text()
    return text

def extract_text_from_docx(file_path: str) -> str:
    doc = Document(file_path)
    text = "\n".join([p.text for p in doc.paragraphs])
    return text
        
def process_pdfs(db, collection_name, pdf_folder_path):
    pdf_collection = db[collection_name]

    # List to store PDF data
    pdf_data_list = []

    # Iterate through files in the directory
    for file in os.listdir(pdf_folder_path):
        file_path = os.path.join(pdf_folder_path, file)
        if file.endswith('.pdf'):
            text = (extract_text_from_pdf(file_path))
        elif file.endswith('.docx'):
            print('docx file')
            text =(extract_text_from_docx(file_path))
        
            # Append PDF data to list
        pdf_data_list.append({
            'pdf_files': text,
            'file_path' : file_path
        
        })

    # Insert all PDFs into MongoDB for the specific collection
    if pdf_data_list:
        result = pdf_collection.insert_many(pdf_data_list)
        print("Inserted", len(result.inserted_ids), "PDFs into", collection_name, "collection")

process_pdfs(db,COLLECTION_NAME,pdf_folder_path)






