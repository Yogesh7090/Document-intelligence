import streamlit as st
from logo import add_logo

st.set_page_config(
    page_title="Home",
    
)
add_logo()
st.markdown(
    """
    <style>
    .custom-title {
        color: #005F7B;
    }
    </style>
    """,
    unsafe_allow_html=True
)

st.markdown('<h1 style = "text-align:center;">Document Intelligent Platform</h1>', unsafe_allow_html=True)
st.markdown('<div style = "font-size: 25px; text-align : center; color:blue;"> <b>Detailed Summary</b> </div>', unsafe_allow_html=True)

st.markdown("""
<br>
            
<b>Overview</b>:  
            Welcome to the future of document management. The Document Intelligence Platform is a revolutionary tool designed for enterprises that require efficient handling and retrieval of document-based information. 
            This platform supports a variety of formats including PDFs and Word documents, integrated with AI and GenAI technology to provide swift access to vital information.
 
<b>Core Features</b>:
1. <b>Advanced Document Handling</b>:
            
    1. Secure uploading and systematic storage of multiple document formats.
    2. Enhanced document cataloguing for easy accessibility and management.
            
2. <b>Smart Retrieval Capabilities</b>:
            
    1. Sophisticated query handling that allows users to extract summaries and key information from documents
    2. Dynamic adaptation to user queries ensuring high relevance and accuracy in information retrieval.
            
3. <b>Intuitive User Interface</b>:
            
    1. Professionally designed interface facilitating straightforward navigation and operation.
    2. Streamlined User Interface: A single, professionally designed page facilitates both querying 
       and summarizing, optimizing user workflow which integrates all essential functionalities into a unified and intuitive interface."""
,unsafe_allow_html=True)


